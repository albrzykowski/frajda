# Frajda Platform

## Overview
Frajda is a microservices-based platform composed of an API Gateway and a Gamification Service. Both services are containerized with Docker and orchestrated via Docker Compose. Shared configuration defines system-wide parameters and gamification rules.

## Architecture and Flow
1. **External client** sends a request to **API Gateway**.
2. **API Gateway** validates and routes the request.
3. Depending on the endpoint, **API Gateway** forwards relevant events to **Gamification Service**.
4. **Gamification Service** applies rules defined in `shared_config/game_rules.{json|yml}`:
   - Interprets incoming events.
   - Calculates points, achievements, or progress.
   - Persists or returns computed results.
5. Responses are sent back through the **API Gateway** to the client.

## Services

### API Gateway
- Entry point for external communication.
- Written in Python.
- Uses dependencies defined in `requirements.txt`.
- Containerized with a dedicated `Dockerfile`.

### Gamification Service
- Core business logic for gamification.
- Organized into:
  - `service.py`: logic for applying game rules.
  - `repository.py`: persistence layer.
  - `main.py`: service entry point.
- Unit tests in `test_events.py`.

### Shared Configuration
- `config.json`: global parameters (API keys, connection strings, etc.).
- `game_rules.json` / `game_rules.yml`: event-based scoring and achievement rules.

## Docker Deployment

### Build and Start
```
docker compose up --build -d
```
This will:
- Build images for `api_gateway` and `gamification_service` using their `Dockerfile`s.
- Start containers defined in `docker-compose.yml`.

### Stopping
```
docker compose down
```

### Rebuilding Images
If you changed dependencies or Dockerfiles:
```
docker compose build --no-cache
```

### Accessing Logs
```
docker compose logs -f api_gateway
docker compose logs -f gamification_service
```

### Entering Containers
```
docker exec -it frajda-api_gateway-1 /bin/bash
docker exec -it frajda-gamification_service-1 /bin/bash
```

## Example Usage

### Sending an Event
Assume API Gateway exposes an endpoint `/events`:
```
curl -X POST http://localhost:<gateway_port>/events \
     -H "Content-Type: application/json" \
     -d '{
           "user_id": "123",
           "event": "task_completed",
         }'
```
The request is routed to the Gamification Service, which applies rules from `shared_config/game_rules.yml` and returns a score update or achievement.


## Development (Local without Docker)

### API Gateway
```
cd api_gateway
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

### Gamification Service
```
cd gamification_service
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

## Configuration Notes
- Modify `shared_config/config.json` for environment variables.
- Adjust `shared_config/game_rules.yml` to define gamification logic (scoring rules, thresholds, rewards).

## Deployment Notes
- For production, build images and push them to a registry:
  ```
  docker compose build
  docker tag frajda-api_gateway:latest <registry>/frajda-api_gateway:latest
  docker tag frajda-gamification_service:latest <registry>/frajda-gamification_service:latest
  docker push <registry>/frajda-api_gateway:latest
  docker push <registry>/frajda-gamification_service:latest
  ```
- Deploy with:
  ```
  docker compose -f docker-compose.yml up -d
  ```

## License
See [LICENSE](LICENSE) for details.